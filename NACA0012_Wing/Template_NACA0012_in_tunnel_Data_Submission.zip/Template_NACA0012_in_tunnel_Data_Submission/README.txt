The example figures and data correspond to USM3D-ME solutions.

The following files are included:

forces.dat is a template for reporting forces and moment computed on each grid in a family. Different grid families are in different zones.

grid_a1_cpcfx.dat is a template for reporting Cp and Cfx surface cuts along Y=-0.001, Y=-0.035 and Y = -0.73 on a given grid (a1).  
Figures grid_convergence_Y_m0p001_cfx.png,  grid_convergence_Y_m0p001_cp.png, grid_convergence_Y_m0p035_cfx.png, grid_convergence_Y_m0p035_cp.png,
grid_convergence_Y_m0p73_cfx.png, and grid_convergence_Y_m0p73_cp.png illustrate grid convergence of Cp and Cfx observed by USM3D-ME on Helden Mesh grid family.

iterative_convergence.dat is an example of USM3D-ME reporting iterative convergence on a given grid
One can use a simpler reporting form. 
VARIABLES= iterations rms_res_mf1 rms_res_mf2 rms_res_mf3 rms_res_mf4 rms_res_mf5 rms_res_trb1 CL CD CDv CM 
  
Figures iterative_convergence_entire_grid_family_cd.png and iterative_convergence_entire_grid_family_residuals_combined.png 
illustrate iterative convergence on all grids in a family.

Figures nu_tilda_contours_grid_e1_X_0p805_SAnegQCR2000_R.png, nu_tilda_contours_grid_e1_X_0p805_SAnegQCR2000.png, 
nu_tilda_contours_grid_e1_X_3p2648_SAnegQCR2000_R.png, nu_tilda_contours_grid_e1_X_3p2648_SAnegQCR2000.png,
pressure_contours_grid_e1_X_0p805_SAnegQCR2000_R.png, pressure_contours_grid_e1_X_0p805_SAnegQCR2000.png,
pressure_contours_grid_e1_X_3p2648_SAnegQCR2000_R.png, pressure_contours_grid_e1_X_3p2648_SAnegQCR2000.png
illustrate contours of nu-tilde and cp in cross-sections corresponding to X=0.805 and X=3.2648. 
Please, use viridis color map and indicate minimum and maximum values within the cross-section on each plot.
