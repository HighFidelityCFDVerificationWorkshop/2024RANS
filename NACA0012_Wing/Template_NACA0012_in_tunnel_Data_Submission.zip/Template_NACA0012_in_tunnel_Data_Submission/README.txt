The example figures and data.

Pressure coefficient is defined as: 

Cp = (p - p_exit)/(Pt_inlet - p_exit), 

where p is the local static pressure, p_exit is the exit static pressure imposed by the BC, and Pt_inlet is the total pressure imposed at the inlet BC.

The SA-working variable nu_tilde should be normalized by the inlet kinematic viscosity: nu_tilde/nu_inlet

The following files are included:

forces.dat is a template for reporting forces and moment computed on each grid in a family. Different grid families are in different zones.

grid_a1_cpcfx.dat is a template for reporting Cp and Cfx surface cuts along Y=-0.001, Y=-0.035 and Y = -0.73 on a given grid (a1).  
Figures grid_convergence_Y_m0p001_cfx.png,  grid_convergence_Y_m0p001_cp.png, grid_convergence_Y_m0p035_cfx.png, grid_convergence_Y_m0p035_cp.png,
grid_convergence_Y_m0p73_cfx.png, and grid_convergence_Y_m0p73_cp.png illustrate grid convergence of Cp and Cfx observed by USM3D-ME on Helden Mesh grid family.

iterative_convergence.dat is an example of USM3D-ME reporting iterative convergence on a given grid
One can use a simpler reporting form. 
VARIABLES= iterations rms_res_mf1 rms_res_mf2 rms_res_mf3 rms_res_mf4 rms_res_mf5 rms_res_trb1 CL CD CDp CDv CM 
  
Figures iterative_convergence_entire_grid_family_cd.png and iterative_convergence_entire_grid_family_residuals_combined.png 
illustrate iterative convergence on all grids in a family.

Figures 
nu_tilda_contours_grid_e1_X_0p8_SAnegQCR2000_R.png, nu_tilda_contours_grid_e1_X_0p8_SAnegQCR2000.png, 
nu_tilda_contours_grid_e1_X_3p0_SAnegQCR2000_R.png, nu_tilda_contours_grid_e1_X_3p0_SAnegQCR2000.png,
pressure_contours_grid_e1_X_0p8_SAnegQCR2000_R.png, pressure_contours_grid_e1_X_0p8_SAnegQCR2000.png,
pressure_contours_grid_e1_X_3p0_SAnegQCR2000_R.png, pressure_contours_grid_e1_X_3p0_SAnegQCR2000.png
illustrate contours of nu-tilde and cp in cross-sections corresponding to X=0.8 and X=3.0. 
Please, use viridis color map and indicate minimum and maximum values within the cross-section on each plot.
For nu_tilde/nu use range 0-1100.
